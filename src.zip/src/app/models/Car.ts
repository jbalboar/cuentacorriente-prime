export interface Car {
    vin: string;
    year:string;
    brand:string;
    color:string;
  }
