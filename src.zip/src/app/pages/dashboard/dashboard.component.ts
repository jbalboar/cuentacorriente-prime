import { Component } from '@angular/core';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [
   
  ],
})
export class DashboardComponent  {
  
  codigo1:number=1;
  codigo2:number=2;
  getCodigo1(){
    `${this.codigo1}%`;
  }
  getCodigo2(){
    `${this.codigo2}%`;
  }

  cambioValorhijo(valor:number){
    console.log('cambio el valor ',valor);
  }
  consultaCuenta():void{
    console.log('HOla Peru');
  }
} 
