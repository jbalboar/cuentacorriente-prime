import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Car } from './../models/Car';
import { Customer } from './../models/customer';
@Injectable({
  providedIn: 'root'
})
export class CarService {

  constructor(private http: HttpClient) {}

  getCarsSmall() {
    return this.http.get<any>('./../assets/data/cars-small.json')
                .toPromise()
                .then(res => <Car[]> res)
                .then(data => { return data; });
}
  getListadeDocumentos(){
    return  new Promise (resolve=>{

      fetch('https://reqres.in/api/users')
      .then(resp=>resp.json())
      .then(body=>resolve(body.data));
    });

  }
  getCustomersLarge() {
    return this.http.get<any>('assets/customers-large.json')
        .toPromise()
        .then(res => <Customer[]>res.data)
        .then(data => { return data; });
}

}
